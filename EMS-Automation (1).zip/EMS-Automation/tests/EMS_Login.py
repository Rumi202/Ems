import time
from selenium.webdriver.common.by import By


    # Check if login is successful
def test_login_to_EMS(driver):
    driver.get("https://ems-test.amaderit.net/")
    driver.find_element(By.NAME, "username").send_keys("adming1")
    driver.find_element(By.NAME, "password").send_keys("123456")


    driver.find_element(By.XPATH, "//button[normalize-space()='Sign In']").click()
